package cn.edu.sut.hotel_management.sql;

import cn.edu.sut.hotel_management.model.*;
import cn.edu.sut.hotel_management.util.Api;

import java.io.InputStream;
import java.sql.*;

public class select {

    public static order getOrder(long id) throws SQLException {
        Api api = new Api();
        String sql = "SELECT * FROM ORDER_TBL WHERE ID =?";
       
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setLong(1, id);
        ResultSet rSet = api.select(pStatement);

        if (rSet.next()) {
            return new order(rSet.getInt(1), rSet.getString(2), rSet.getInt(3), rSet.getFloat(4), rSet.getFloat(5), rSet.getFloat(6), rSet.getString(7), rSet.getString(8), rSet.getString(9));
        } else {
            return null;
        }
    }

    public static Object[][] getAllMyOrder(long id) throws SQLException {
        Api api = new Api();
        String sql = "SELECT ORDER_TBL.* FROM ORDER_TBL INNER JOIN RELATION_TBL ON ORDER_TBL.ID = RELATION_TBL.ORDER_ID INNER JOIN USER_TBL ON RELATION_TBL.USER_ID = USER_TBL.ID WHERE USER_TBL.ID =?";
       
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setLong(1, id);
        ResultSet rSet = api.select(pStatement);

        int row = 0;
        int col = 0;
        while (rSet.next()) {
            row++;
        }
        if (row == 0) {
            return null;
        }
        Object[][] data;
        data = new Object[row][6];
        rSet.beforeFirst();
        for (; row > 0; row--) {
            rSet.next();
            data[col][0] = rSet.getLong(1);
            data[col][1] = rSet.getString(2);
            data[col][2] = rSet.getString(3);
            data[col][3] = rSet.getString(4);
            data[col][4] = rSet.getString(5);
            data[col][5] = rSet.getInt(6);
            col++;
        }
        return data;
    }

    public static int getDateCur(String start) throws SQLException {
        Api api = new Api();
        String sql = "SELECT DATEDIFF(?,CURRENT_DATE)";
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, start);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return rSet.getInt(1);
        }
        return -1;
    }

    public static Object[][] getAllRoom() throws SQLException {
        Api api = new Api();
        String sql = "SELECT ROOM.ID, ROOM.NUM, ROOM_TYPE.TYPE, PRICE.PREPAY, PRICE.MONEY, ROOM.STATUS FROM ROOM INNER JOIN ROOM_TYPE ON ROOM.TYPE_ID = ROOM_TYPE.ID INNER JOIN PRICE ON ROOM.PRICE_ID = PRICE.ID";
       
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        ResultSet rSet = api.select(pStatement);

        int row = 0;
        int col = 0;
        while (rSet.next()) {
            row++;
        }
        if (row == 0) {
            return null;
        }
        Object[][] data;
        data = new Object[row][6];
        rSet.beforeFirst();
        for (; row > 0; row--) {
            rSet.next();
            data[col][0] = rSet.getString(1);
            data[col][1] = rSet.getString(2);
            data[col][2] = rSet.getString(3);
            data[col][3] = rSet.getString(4);
            data[col][4] = rSet.getString(5);
            data[col][5] = rSet.getString(6);
            col++;
        }
        return data;
    }

    public static Object[][] getAllUser() throws SQLException {
        Api api = new Api();
        String sql = "SELECT USER_TBL.ID, USER_TBL.ACCOUNT,USER_TBL.USER_NAME, USER_TBL.NAME, USER_TBL.TEL FROM USER_TBL";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        ResultSet rSet = api.select(pStatement);

        int row = 0;
        int col = 0;
        while (rSet.next()) {
            row++;
        }
        if (row == 0) {
            return null;
        }
        Object[][] data;
        data = new Object[row][6];
        rSet.beforeFirst();
        for (; row > 0; row--) {
            rSet.next();
            data[col][0] = rSet.getString(1);
            data[col][1] = rSet.getString(2);
            data[col][2] = rSet.getString(3);
            data[col][3] = rSet.getString(4);
            data[col][4] = rSet.getString(5);
            data[col][5] = (select.isAdmin(rSet.getString(1))? "是" : "否");
            col++;
        }
        return data;
    }

    public static relation getRelation(int id) throws SQLException {
        Api api = new Api();
        String sql = "SELECT * FROM RELATION_TBL WHERE ID =?";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setInt(1, id);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return new relation(rSet.getInt(1), rSet.getLong(2), rSet.getInt(3), rSet.getLong(4), rSet.getInt(5), rSet.getString(6));

        } else {
            return null;
        }
    }


    public static String[] getAllRoomType() throws SQLException {
        Api api = new Api();
        String sql = "SELECT DISTINCT ROOM_TYPE.TYPE FROM ROOM_TYPE";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        ResultSet rSet = api.select(pStatement);

        int row = 0;
        int col = 0;
        while (rSet.next()) {
            row++;
        }
        if (row == 0) {
            return null;
        }
        String[] data;
        data = new String[row];
        rSet.beforeFirst();
        for (; row > 0; row--) {
            rSet.next();
            data[col] = rSet.getString(1);
            col++;
        }
        return data;
    }

    public static String[] getAllRoomNum(String type) throws SQLException {
        Api api = new Api();
        String sql = "SELECT ROOM.NUM FROM ROOM_TYPE INNER JOIN ROOM ON ROOM_TYPE.ID = ROOM.TYPE_ID WHERE ROOM_TYPE.TYPE =?";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, type);
        ResultSet rSet = api.select(pStatement);

        int row = 0;
        int col = 0;
        while (rSet.next()) {
            row++;
        }
        if (row == 0) {
            return null;
        }
        String[] data;
        data = new String[row];
        rSet.beforeFirst();
        for (; row > 0; row--) {
            rSet.next();
            data[col] = rSet.getString(1);
            col++;
        }
        return data;
    }

    public static room getRoom(int id) throws SQLException {
        Api api = new Api();
        String sql = "SELECT ROOM.ID, ROOM.NUM, ROOM_TYPE.TYPE, PRICE.PREPAY, PRICE.MONEY, ROOM.STATUS FROM ROOM INNER JOIN ROOM_TYPE ON ROOM.TYPE_ID = ROOM_TYPE.ID INNER JOIN PRICE ON ROOM.PRICE_ID = PRICE.ID WHERE ROOM.ID =?";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setInt(1, id);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return new room(rSet.getInt(1), rSet.getString(2), rSet.getString(3), rSet.getFloat(4), rSet.getFloat(5), rSet.getString(6));
        } else {
            return null;
        }
    }

    public static float[] getRoomPrice(String id) throws SQLException {
        Api api = new Api();
        String sql = "SELECT PRICE.PREPAY, PRICE.MONEY FROM PRICE INNER JOIN ROOM ON PRICE.ID = ROOM.PRICE_ID WHERE ROOM.NUM =?";
       
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, id);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return new float[]{rSet.getFloat(1), rSet.getFloat(2)};
        } else {
            return null;
        }
    }


    public static boolean isAccountExist(String account) throws SQLException {
        Api api = new Api();
        String sql = "SELECT ACCOUNT FROM USER_TBL WHERE USER_TBL.ACCOUNT =?";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, account);
        ResultSet rSet = api.select(pStatement);
        return rSet.next();
    }

    public static String getPriceId(float prepay, float money) throws SQLException {
        Api api = new Api();
        String sql = "SELECT PRICE.ID FROM PRICE WHERE PRICE.PREPAY =? AND PRICE.MONEY =?";
       
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setFloat(1, prepay);
        pStatement.setFloat(2, money);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return rSet.getString(1);
        }
        return null;
    }

    public static String getRoomId(String num) throws SQLException {
        Api api = new Api();
        String sql = "SELECT ROOM.ID FROM ROOM WHERE ROOM.NUM =?";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, num);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return rSet.getString(1);

        }
        return null;
    }

    public static String getTypeId(String num) throws SQLException {
        Api api = new Api();
        String sql = "SELECT ROOM_TYPE.ID FROM ROOM_TYPE WHERE ROOM_TYPE.TYPE =?";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, num);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return rSet.getString(1);

        }
        return null;
    }

    public static String getOrderNum() throws SQLException {
        Api api = new Api();
        String sql = "SELECT COUNT(ORDER_TBL.ID) FROM ORDER_TBL INNER JOIN RELATION_TBL ON ORDER_TBL.ID = RELATION_TBL.ORDER_ID INNER JOIN USER_TBL ON USER_TBL.ID = RELATION_TBL.USER_ID WHERE USER_TBL.ID =?";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setLong(1, curuser.getId());
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return rSet.getString(1);
        }
        return null;
    }

    public static int getDateDiff(String end, String start) throws SQLException {
        Api api = new Api();
        String sql = "SELECT DATEDIFF(?,?)";
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, start);
        pStatement.setString(2, end);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return rSet.getInt(1);
        }
        return -1;
    }

    public static curuser getCurUser(long id) throws SQLException {
        Api api = new Api();
        String sql = "SELECT * FROM USER_TBL WHERE ID =?";
   
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setLong(1, id);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return new curuser(rSet.getLong(1), rSet.getString(2), rSet.getString(3), rSet.getString(4), rSet.getString(5), rSet.getString(6), rSet.getString(7), rSet.getString(8), rSet.getString(9), rSet.getString(10));
        } else {
            return null;
        }
    }

    public static user getUser(long id) throws SQLException {
        Api api = new Api();
        String sql = "SELECT USER_TBL.NAME, USER_TBL.TEL, USER_TBL.ACCOUNT, USER_TBL.USER_NAME FROM USER_TBL WHERE USER_TBL.ID =?";
     
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setLong(1, id);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            return new user(id, rSet.getString(1), rSet.getString(2), rSet.getString(3), rSet.getString(4));
        } else {
            return null;
        }
    }

    public static boolean login(String id, String password) throws SQLException {
        Api api = new Api();
        String sql = "SELECT PASSWORD FROM USER_TBL WHERE ACCOUNT =?";
       
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, id);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            String pwd = rSet.getString(1);
            return password.equals(pwd);
        }
        return false;
    }

    public static boolean isAdmin() throws SQLException {
        Api api = new Api();
        String sql = "SELECT USER_TBL.ADMIN FROM USER_TBL WHERE USER_TBL.ID =?";
       
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setLong(1, curuser.getId());
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            int isad = rSet.getInt(1);
            return isad == 1;
        }
        return false;
    }

    public static boolean isAdmin(String id) throws SQLException {
        Api api = new Api();
        String sql = "SELECT USER_TBL.ADMIN FROM USER_TBL WHERE USER_TBL.ID =?";
        
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setString(1, id);
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {
            int isad = rSet.getInt(1);
            return isad == 1;
        }
        return false;
    }

    public static String getPassword() throws SQLException {
        Api api = new Api();
        String sql = "SELECT PASSWORD FROM USER_TBL WHERE ID =?";
       
        PreparedStatement pStatement = api.getPreparedStatement(sql);
        pStatement.setLong(1, curuser.getId());
        ResultSet rSet = api.select(pStatement);
        if (rSet.next()) {        return rSet.getString(1);
    }
    return null;
}

public static long getId(String account) throws SQLException {
    Api api = new Api();
    String sql = "SELECT ID FROM USER_TBL WHERE ACCOUNT =?";
 
    PreparedStatement pStatement = api.getPreparedStatement(sql);
    pStatement.setString(1, account);
    ResultSet rSet = api.select(pStatement);
    if (rSet.next()) {
        return rSet.getLong(1);
    }
    return -1;
}

public static InputStream loadPicture() throws SQLException {
    Api api = new Api();
    String sql = "SELECT IMG FROM USER_TBL WHERE ID =?";
    
    Connection conn = api.getConnection();
    PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
    ps.setLong(1, curuser.getId());
    ResultSet resultSet = ps.executeQuery();
    InputStream img;
    if (resultSet.next()) {
        img = resultSet.getBinaryStream(1);
        return img;
    }
    return null;
}
}