package cn.edu.sut.hotel_management.util;

public interface dbconfig {
    String JDBC_DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    String JDBC_URL = "jdbc:derby:hotel_managementDB;create=true";
    String JDBC_USER = "root";
    String JDBC_PASSWORD = "5354778";
}
