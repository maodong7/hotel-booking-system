package cn.edu.sut.hotel_management;

import cn.edu.sut.hotel_management.ui.Login;
import cn.edu.sut.hotel_management.util.dbconfig;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) {
        Login l = new Login();
        l.setVisible(true);
    }
}