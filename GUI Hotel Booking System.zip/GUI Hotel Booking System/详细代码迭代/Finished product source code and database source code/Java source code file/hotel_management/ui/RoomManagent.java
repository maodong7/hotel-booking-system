package cn.edu.sut.hotel_management.ui;

import cn.edu.sut.hotel_management.model.curuser;
import cn.edu.sut.hotel_management.sql.select;
import cn.edu.sut.hotel_management.ui.component.RoomTable;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class RoomManagent extends JPanel {

    public RoomManagent() throws SQLException {
        // 显示当前用户ID
        System.out.println(curuser.getId());

        // 创建RoomTable实例
        RoomTable roomTable = new RoomTable();

        // 设置布局为BorderLayout
        setLayout(new BorderLayout());

        // 创建顶部面板
        JPanel jPanel = new JPanel();

        // 创建标签和按钮
        JLabel jl1 = new JLabel("按住CTRL可多选");
        JButton add = new JButton("添加");
        JButton look = new JButton("管理");
        JButton reload = new JButton("刷新");
        JButton btnAddType = new JButton("新增房型");

        // 获取表格和其模型
        JTable myTable = roomTable.getTable();
        DefaultTableModel model = (DefaultTableModel) myTable.getModel();
        roomTable.setViewportView(myTable);

        // 设置表格列标题
        String[] header = new String[]{"房间id", "房间号", "房间类型", "预付款金额", "租金金额", "状态"};
        // 从数据库获取房间数据并设置到表格模型
        try {
            model.setDataVector(select.getAllRoom(), header);
        } catch (SQLException e) {
            // 处理数据库查询异常，显示错误信息
            JOptionPane.showMessageDialog(null, "加载房间信息失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }

        // 查看按钮的点击事件处理
        look.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = myTable.getSelectedRow();
                if (selectedRow == -1) {
                    // 如果没有选中行，提示用户
                    JOptionPane.showMessageDialog(null, "请选择要查看的房间！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                int selectedRows = myTable.getSelectedRows().length;
                if (selectedRows > 1) {
                    // 如果选择了多行，提示每次只能查看一个
                    JOptionPane.showMessageDialog(null, "每次只能查看一个！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                try {
                    int id = Integer.parseInt((String) myTable.getValueAt(selectedRow, 0));
                    RoomDetil r = new RoomDetil(id);
                    r.setVisible(true);
                } catch (NumberFormatException ex) {
                    // 处理解析房间ID失败的情况，显示错误信息
                    JOptionPane.showMessageDialog(null, "获取房间ID失败：" + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 刷新按钮的点击事件处理
        reload.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    model.setDataVector(select.getAllRoom(), header);
                    myTable.updateUI();
                } catch (SQLException ex) {
                    // 处理数据库查询异常，显示错误信息
                    JOptionPane.showMessageDialog(null, "刷新房间信息失败：" + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 添加按钮的点击事件处理
        add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddRoom.create();
            }
        });

        // 将标签和按钮添加到顶部面板
        jPanel.add(jl1);
        jPanel.add(add);
        jPanel.add(look);
        jPanel.add(reload);

        // 将顶部面板添加到北部，将表格添加到中心
        add(jPanel, BorderLayout.NORTH);
        add(roomTable, BorderLayout.CENTER);
    }
}