/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;

public class UserFrame extends JFrame {
    public UserFrame() {
        setTitle("酒店预订系统 - 用户界面");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // 这里可以添加用户界面的组件和功能
        JLabel userLabel = new JLabel("欢迎用户！");
        add(userLabel);
    }
}
