/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDatabase {
    public static void main(String[] args) {
        try {
            // 加载 Derby 驱动
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");

            // 创建数据库连接
            String url = "jdbc:derby:hotelDB;create=true";
            Connection connection = DriverManager.getConnection(url);

            // 创建表的 SQL 语句
            String createUsersTableSQL = "CREATE TABLE users (" +
                    "id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
                    "username VARCHAR(50) NOT NULL," +
                    "password VARCHAR(50) NOT NULL," +
                    "role VARCHAR(10) NOT NULL" +
                    ")";

            String createRoomsTableSQL = "CREATE TABLE rooms (" +
                    "id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
                    "room_number INT NOT NULL," +
                    "availability BOOLEAN NOT NULL" +
                    ")";

            String createBookingsTableSQL = "CREATE TABLE bookings (" +
                    "id INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
                    "user_id INT NOT NULL," +
                    "room_id INT NOT NULL," +
                    "check_in_date DATE NOT NULL," +
                    "check_out_date DATE NOT NULL" +
                    ")";

            // 执行 SQL 语句创建表
            Statement statement = connection.createStatement();
            statement.execute(createUsersTableSQL);
            statement.execute(createRoomsTableSQL);
            statement.execute(createBookingsTableSQL);

            statement.close();
            connection.close();

            System.out.println("数据库和表创建成功！");

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
