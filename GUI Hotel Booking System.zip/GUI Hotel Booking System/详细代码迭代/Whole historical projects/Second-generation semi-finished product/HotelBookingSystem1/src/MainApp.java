/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class MainApp {
    public static void main(String[] args) {
        // 创建酒店预订系统管理员界面实例
        HotelAdminPanel adminPanel = new HotelAdminPanel();
        // 设置界面可见
        adminPanel.setVisible(true);
    }
}
