/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HotelAdminPanel extends JFrame {
    private JTable roomTable;
    private JTable bookingTable;
    private JTable customerTable;
    private JButton addRoomButton;
    private JButton editRoomButton;
    private JButton viewBookingsButton;
    private JButton addBookingButton;
    private JButton manageCustomersButton;
    private JButton searchCustomersButton;
    private JButton editCustomerButton;

    public HotelAdminPanel() {
        setTitle("Hotel Admin Panel");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 创建菜单栏
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        fileMenu.add(exitMenuItem);
        menuBar.add(fileMenu);
        setJMenuBar(menuBar);

        // 创建房间列表面板
        JPanel roomPanel = new JPanel(new BorderLayout());
        String[] roomColumns = {"Room Number", "Type", "Price", "Availability"};
        roomTable = new JTable();
        JScrollPane roomScrollPane = new JScrollPane(roomTable);
        roomPanel.add(roomScrollPane, BorderLayout.CENTER);

        // 创建房间操作按钮面板
        JPanel roomButtonPanel = new JPanel();
        addRoomButton = new JButton("Add Room");
        editRoomButton = new JButton("Edit Room");
        roomButtonPanel.add(addRoomButton);
        roomButtonPanel.add(editRoomButton);
        roomPanel.add(roomButtonPanel, BorderLayout.SOUTH);

        // 创建预订记录面板
        JPanel bookingPanel = new JPanel(new BorderLayout());
        String[] bookingColumns = {"Booking ID", "Customer Name", "Room Number", "Check-in Date", "Check-out Date"};
        bookingTable = new JTable();
        JScrollPane bookingScrollPane = new JScrollPane(bookingTable);
        bookingPanel.add(bookingScrollPane, BorderLayout.CENTER);
        viewBookingsButton = new JButton("View Bookings");
        bookingPanel.add(viewBookingsButton, BorderLayout.SOUTH);

        // 创建客户信息面板
        JPanel customerPanel = new JPanel(new BorderLayout());
        String[] customerColumns = {"Customer ID", "Name", "Email", "Phone"};
        customerTable = new JTable();
        JScrollPane customerScrollPane = new JScrollPane(customerTable);
        customerPanel.add(customerScrollPane, BorderLayout.CENTER);

        // 创建客户操作按钮面板
        JPanel customerButtonPanel = new JPanel();
        manageCustomersButton = new JButton("Manage Customers");
        searchCustomersButton = new JButton("Search Customers");
        editCustomerButton = new JButton("Edit Customer");
        addBookingButton = new JButton("Add Booking");
        customerButtonPanel.add(manageCustomersButton);
        customerButtonPanel.add(searchCustomersButton);
        customerButtonPanel.add(editCustomerButton);
        customerButtonPanel.add(addBookingButton);
        customerPanel.add(customerButtonPanel, BorderLayout.SOUTH);

        // 将各个面板添加到主框架
        JSplitPane splitPane1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, roomPanel, bookingPanel);
        JSplitPane splitPane2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, splitPane1, customerPanel);
        add(splitPane2, BorderLayout.CENTER);

        // 添加按钮监听器
        addRoomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 添加房间的逻辑
                String roomNumber = JOptionPane.showInputDialog("Enter room number:");
                String roomType = JOptionPane.showInputDialog("Enter room type:");
                double roomPrice = Double.parseDouble(JOptionPane.showInputDialog("Enter room price:"));
                boolean availability = Boolean.parseBoolean(JOptionPane.showInputDialog("Is the room available? (true/false)"));

                try {
                    Connection connection = DriverManager.getConnection("jdbc:derby:hotel_database;create=true");
                    String sql = "INSERT INTO rooms (room_number, room_type, room_price, availability) VALUES (?,?,?,?)";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, roomNumber);
                    statement.setString(2, roomType);
                    statement.setDouble(3, roomPrice);
                    statement.setBoolean(4, availability);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        JOptionPane.showMessageDialog(null, "Room added successfully.");
                    }
                    statement.close();
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error adding room: " + ex.getMessage());
                }
            }
        });

        editRoomButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 编辑房间信息的逻辑
                int selectedRow = roomTable.getSelectedRow();
                if (selectedRow!= -1) {
                    String roomNumber = (String) roomTable.getValueAt(selectedRow, 0);
                    String roomType = JOptionPane.showInputDialog("Enter new room type:", (String) roomTable.getValueAt(selectedRow, 1));
                    double roomPrice = Double.parseDouble(JOptionPane.showInputDialog("Enter new room price:", String.valueOf(roomTable.getValueAt(selectedRow, 2))));
                    boolean availability = Boolean.parseBoolean(JOptionPane.showInputDialog("Is the room available? (true/false):", String.valueOf(roomTable.getValueAt(selectedRow, 3))));

                    try {
                        Connection connection = DriverManager.getConnection("jdbc:derby:hotel_database;create=true");
                        String sql = "UPDATE rooms SET room_type =?, room_price =?, availability =? WHERE room_number =?";
                        PreparedStatement statement = connection.prepareStatement(sql);
                        statement.setString(1, roomType);
                        statement.setDouble(2, roomPrice);
                        statement.setBoolean(3, availability);
                        statement.setString(4, roomNumber);
                        int rowsUpdated = statement.executeUpdate();
                        if (rowsUpdated > 0) {
                            JOptionPane.showMessageDialog(null, "Room updated successfully.");
                        }
                        statement.close();
                        connection.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error updating room: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a room to edit.");
                }
            }
        });

        viewBookingsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 查看预订记录的逻辑
                try {
                    Connection connection = DriverManager.getConnection("jdbc:derby:hotel_database;create=true");
                    String sql = "SELECT * FROM bookings";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    ResultSet resultSet = statement.executeQuery();
                    Object[][] data = new Object[0][];
                    int rowCount = 0;
                    while (resultSet.next()) {
                        data = Arrays.copyOf(data, data.length + 1);
                        data[rowCount] = new Object[]{resultSet.getString("booking_id"), resultSet.getString("customer_name"),
                                resultSet.getString("room_number"), resultSet.getString("check_in_date"), resultSet.getString("check_out_date")};
                        rowCount++;
                    }
                    String[] columnNames = {"Booking ID", "Customer Name", "Room Number", "Check-in Date", "Check-out Date"};
                    bookingTable.setModel(new DefaultTableModel(data, columnNames));
                    statement.close();
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error fetching bookings: " + ex.getMessage());
                }
            }
        });

        addBookingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 添加新预订的逻辑
                String customerName = JOptionPane.showInputDialog("Enter customer name:");
                String roomNumber = JOptionPane.showInputDialog("Enter room number:");
                String checkInDate = JOptionPane.showInputDialog("Enter check-in date:");
                String checkOutDate = JOptionPane.showInputDialog("Enter check-out date:");

                try {
                    Connection connection = DriverManager.getConnection("jdbc:derby:hotel_database;create=true");
                    String sql = "INSERT INTO bookings (customer_name, room_number, check_in_date, check_out_date) VALUES (?,?,?,?)";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, customerName);
                    statement.setString(2, roomNumber);
                    statement.setString(3, checkInDate);
                    statement.setString(4, checkOutDate);
                    int rowsInserted = statement.executeUpdate();
                    if (rowsInserted > 0) {
                        JOptionPane.showMessageDialog(null, "Booking added successfully.");
                    }
                    statement.close();
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error adding booking: " + ex.getMessage());
                }
            }
        });

        manageCustomersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 管理客户信息的逻辑
                try {
                    Connection connection = DriverManager.getConnection("jdbc:derby:hotel_database;create=true");
                    String sql = "SELECT * FROM customers";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    ResultSet resultSet = statement.executeQuery();
                    Object[][] data = new Object[0][];
                    int rowCount = 0;
                    while (resultSet.next()) {
                        data = Arrays.copyOf(data, data.length + 1);
                        data[rowCount] = new Object[]{resultSet.getString("customer_id"), resultSet.getString("customer_name"),
                                resultSet.getString("email"), resultSet.getString("phone")};
                        rowCount++;
                    }
                    String[] columnNames = {"Customer ID", "Name", "Email", "Phone"};
                    customerTable.setModel(new DefaultTableModel(data, columnNames));
                    statement.close();
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error fetching customers: " + ex.getMessage());
                }
            }
        });

        searchCustomersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 搜索客户记录的逻辑
                String searchTerm = JOptionPane.showInputDialog("Enter search term:");
                try {
                    Connection connection = DriverManager.getConnection("jdbc:derby:hotel_database;create=true");
                    String sql = "SELECT * FROM customers WHERE customer_name LIKE? OR email LIKE? OR phone LIKE?";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, "%" + searchTerm + "%");
                    statement.setString(2, "%" + searchTerm + "%");
                    statement.setString(3, "%" + searchTerm + "%");
                    ResultSet resultSet = statement.executeQuery();
                    Object[][] data = new Object[0][];
                    int rowCount = 0;
                    while (resultSet.next()) {
                        data = Arrays.copyOf(data, data.length + 1);
                        data[rowCount] = new Object[]{resultSet.getString("customer_id"), resultSet.getString("customer_name"),
                                resultSet.getString("email"), resultSet.getString("phone")};
                        rowCount++;
                    }
                    String[] columnNames = {"Customer ID", "Name", "Email", "Phone"};
                    customerTable.setModel(new DefaultTableModel(data, columnNames));
                    statement.close();
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error searching customers: " + ex.getMessage());
                }
            }
        });

        editCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 编辑客户记录的逻辑
                int selectedRow = customerTable.getSelectedRow();
                if (selectedRow!= -1) {
                    String customerId = (String) customerTable.getValueAt(selectedRow, 0);
                    String customerName = JOptionPane.showInputDialog("Enter new customer name:", (String) customerTable.getValueAt(selectedRow, 1));
                    String email = JOptionPane.showInputDialog("Enter new email:", (String) customerTable.getValueAt(selectedRow, 2));
                    String phone = JOptionPane.showInputDialog("Enter new phone:", (String) customerTable.getValueAt(selectedRow, 3));

                    try {
                        Connection connection = DriverManager.getConnection("jdbc:derby:hotel_database;create=true");
                        String sql = "UPDATE customers SET customer_name =?, email =?, phone =? WHERE customer_id =?";
                        PreparedStatement statement = connection.prepareStatement(sql);
                        statement.setString(1, customerName);
                        statement.setString(2, email);
                        statement.setString(3, phone);
                        statement.setString(4, customerId);
                        int rowsUpdated = statement.executeUpdate();
                        if (rowsUpdated > 0) {
                            JOptionPane.showMessageDialog(null, "Customer updated successfully.");
                        }
                        statement.close();
                        connection.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error updating customer: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a customer to edit.");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            HotelAdminPanel adminGUI = new HotelAdminPanel();
            adminGUI.setVisible(true);
        });
    }
}
